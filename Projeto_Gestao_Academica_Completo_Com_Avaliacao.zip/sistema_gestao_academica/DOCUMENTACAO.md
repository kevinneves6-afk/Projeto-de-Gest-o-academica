# Documentação curta — Sistema de Gestão Acadêmica Integrado

## Integrantes
Preencher com os nomes dos integrantes das equipes ALFA e BETA.

## Organização do projeto
- `main.py`: ponto de entrada e interface gráfica Tkinter.
- `models.py`: entidades `Aluno`, `Curso`, `Professor` e `Disciplina`, com construtores, `__str__`, propriedades e conversão para/de linha de texto.
- `managers.py`: gerenciadores com operações CRUD, carregamento, pesquisa, validação de vínculos e persistência.
- `dados/alunos.txt`: registros de alunos.
- `dados/cursos.txt`: registros de cursos.
- `dados/professores.txt`: registros de professores.
- `dados/disciplinas.txt`: registros de disciplinas.

## Formato escolhido para os arquivos TXT
Cada registro é armazenado em uma linha. Os campos são separados por ponto e vírgula (`;`) para permitir a leitura e reconstrução dos objetos. O caractere `;` não é permitido dentro dos campos de texto, pois funciona como delimitador.

- Aluno: `matricula;nome;cpf;email;codigo_curso`
- Curso: `codigo_curso;nome;modalidade`
- Professor: `codigo_professor;nome;cpf;especialidade`
- Disciplina: `codigo_disciplina;nome;carga_horaria;codigo_professor;codigo_curso`

## Integração entre os módulos
O aluno referencia um curso por `codigo_curso`. A disciplina referencia um professor por `codigo_professor` e um curso por `codigo_curso`. O sistema verifica se os registros referenciados existem antes de salvar. Também impede excluir cursos ou professores que ainda tenham vínculos ativos, evitando referências inválidas.

## Dificuldades de integração consideradas
A principal atenção é manter os códigos identificadores iguais entre os módulos e respeitar a ordem de cadastro: primeiro curso e professor; depois disciplina; por fim aluno. Outra preocupação é manter o formato dos arquivos TXT consistente para que todos os gerenciadores consigam reconstruir os objetos corretamente.

## Demonstração sugerida
1. Cadastre um curso (por exemplo, código `ADS`, nome `Análise e Desenvolvimento de Sistemas`, modalidade `Presencial`).
2. Cadastre um professor com código `P01`.
3. Cadastre uma disciplina vinculando os códigos `P01` e `ADS`.
4. Cadastre um aluno usando o código de curso `ADS`.
5. Abra a aba **Relatório integrado** e clique em **Gerar relatório**.
6. Mostre a pasta `dados` para demonstrar que os registros ficaram salvos nos arquivos TXT.


## Módulo de Avaliação Acadêmica (RF19–RF24)

- **RF19:** nova entidade `Nota`, vinculada à matrícula do aluno e ao código da disciplina, com três notas e três pesos.
- **RF20:** persistência no arquivo `dados/notas.txt`, no formato `matricula;codigo_disciplina;nota1;peso1;nota2;peso2;nota3;peso3`.
- **RF21:** cálculo automático da média ponderada durante a listagem e a geração do relatório.
- **RF22:** notas limitadas ao intervalo de 0,0 a 10,0; pesos devem ser positivos para permitir o cálculo; a média é protegida pelo teto de 10,0.
- **RF23:** relatório de rendimento com nome do aluno, nome da disciplina, notas, pesos, média final e status (Aprovado para média maior ou igual a 7,0; Reprovado abaixo de 7,0).
- **RF24:** a média não é gravada no arquivo; é recalculada a cada leitura a partir das notas e pesos atuais. Alterações são refletidas automaticamente na próxima listagem/relatório.

A interface inclui a aba **Notas e avaliações**, com cadastro, alteração, exclusão, listagem e relatório de rendimento. O sistema verifica se aluno e disciplina existem e se a disciplina pertence ao curso do aluno. Também impede excluir aluno ou disciplina que possua avaliação vinculada.
