"""Ponto de entrada: interface gráfica Tkinter do Sistema de Gestão Acadêmica."""
import tkinter as tk
from tkinter import ttk, messagebox
from models import Aluno, Curso, Professor, Disciplina, Nota
from managers import gerenciadores

class Aplicacao:
    def __init__(self, root):
        self.root = root
        self.root.title("Sistema de Gestão Acadêmica Integrado")
        self.root.geometry("1180x760")
        self.root.minsize(960, 620)
        self.root.configure(bg="#f3f6fb")
        self.estilo = ttk.Style()
        try: self.estilo.theme_use("clam")
        except tk.TclError: pass
        self.estilo.configure("TNotebook", background="#f3f6fb", borderwidth=0)
        self.estilo.configure("TNotebook.Tab", padding=(16, 10), font=("Segoe UI", 10, "bold"))
        self.estilo.configure("Treeview", rowheight=28, font=("Segoe UI", 9))
        self.estilo.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"))
        self.estilo.configure("TButton", padding=(10, 7), font=("Segoe UI", 9))
        self._montar_cabecalho()
        self.abas = ttk.Notebook(root)
        self.abas.pack(fill="both", expand=True, padx=18, pady=(0, 12))
        self.configs = {
            "Alunos": {
                "key":"alunos", "class":Aluno, "id":"matricula",
                "fields":[("matricula","Matrícula"),("nome","Nome"),("cpf","CPF"),("email","E-mail"),("codigo_curso","Código do curso")],
                "columns":[("matricula","Matrícula",110),("nome","Nome",180),("cpf","CPF",125),("email","E-mail",190),("codigo_curso","Curso",90)],
                "hint":"Cadastre o curso antes de cadastrar o aluno."
            },
            "Cursos": {
                "key":"cursos", "class":Curso, "id":"codigo_curso",
                "fields":[("codigo_curso","Código do curso"),("nome","Nome"),("modalidade","Modalidade (Presencial/EAD)")],
                "columns":[("codigo_curso","Código",100),("nome","Nome",250),("modalidade","Modalidade",140)],
                "hint":"Modalidade aceita: Presencial ou EAD."
            },
            "Professores": {
                "key":"professores", "class":Professor, "id":"codigo_professor",
                "fields":[("codigo_professor","Código do professor"),("nome","Nome"),("cpf","CPF"),("especialidade","Especialidade")],
                "columns":[("codigo_professor","Código",100),("nome","Nome",220),("cpf","CPF",140),("especialidade","Especialidade",220)],
                "hint":"Cadastre o professor antes de vincular uma disciplina."
            },
            "Disciplinas": {
                "key":"disciplinas", "class":Disciplina, "id":"codigo_disciplina",
                "fields":[("codigo_disciplina","Código da disciplina"),("nome","Nome"),("carga_horaria","Carga horária (horas)"),("codigo_professor","Código do professor"),("codigo_curso","Código do curso")],
                "columns":[("codigo_disciplina","Código",100),("nome","Nome",210),("carga_horaria","Carga horária",105),("codigo_professor","Professor",105),("codigo_curso","Curso",95)],
                "hint":"O professor e o curso precisam estar cadastrados."
            }
        }
        self.widgets = {}
        for nome, cfg in self.configs.items():
            self._montar_aba(nome, cfg)
        self._montar_relatorio()
        self._montar_aba_notas()
        self.atualizar_tudo()
        avisos = [aviso for ger in gerenciadores.values() for aviso in ger.avisos_carregamento]
        if avisos:
            messagebox.showwarning("Avisos ao carregar os dados", "O sistema foi iniciado, mas encontrou estas situações:\n\n" + "\n".join(avisos[:12]))

    def _montar_cabecalho(self):
        cab = tk.Frame(self.root, bg="#152b4a", padx=22, pady=18)
        cab.pack(fill="x")
        tk.Label(cab, text="GESTÃO ACADÊMICA", font=("Segoe UI", 19, "bold"),
                 fg="white", bg="#152b4a").pack(anchor="w")
        tk.Label(cab, text="Sistema integrado • Python + POO + arquivos TXT",
                 font=("Segoe UI", 10), fg="#d4e2f5", bg="#152b4a").pack(anchor="w", pady=(4,0))

    def _montar_aba(self, nome, cfg):
        frame = ttk.Frame(self.abas, padding=14)
        self.abas.add(frame, text=nome)
        topo = ttk.Frame(frame)
        topo.pack(fill="x", pady=(0,8))
        ttk.Label(topo, text=f"Gerenciamento de {nome.lower()}",
                  font=("Segoe UI", 14, "bold")).pack(side="left")
        ttk.Label(frame, text=cfg["hint"], foreground="#52657d").pack(anchor="w", pady=(0,8))
        form = ttk.LabelFrame(frame, text="Dados do registro", padding=10)
        form.pack(fill="x", pady=(0,10))
        entradas = {}
        for i, (campo, rotulo) in enumerate(cfg["fields"]):
            linha, coluna = divmod(i, 3)
            celula = ttk.Frame(form)
            celula.grid(row=linha, column=coluna, sticky="ew", padx=6, pady=5)
            ttk.Label(celula, text=rotulo).pack(anchor="w")
            ent = ttk.Entry(celula, width=30)
            ent.pack(fill="x", pady=(3,0))
            entradas[campo] = ent
            form.columnconfigure(coluna, weight=1)
        acoes = ttk.Frame(frame)
        acoes.pack(fill="x", pady=(0,10))
        ttk.Button(acoes, text="Cadastrar", command=lambda n=nome: self.cadastrar(n)).pack(side="left", padx=(0,6))
        ttk.Button(acoes, text="Alterar selecionado", command=lambda n=nome: self.alterar(n)).pack(side="left", padx=6)
        ttk.Button(acoes, text="Excluir selecionado", command=lambda n=nome: self.excluir(n)).pack(side="left", padx=6)
        ttk.Button(acoes, text="Limpar campos", command=lambda n=nome: self.limpar(n)).pack(side="left", padx=6)
        busca = ttk.Frame(frame)
        busca.pack(fill="x", pady=(0,8))
        ttk.Label(busca, text="Pesquisar por código/matrícula ou nome:").pack(side="left")
        pesquisa = ttk.Entry(busca, width=30)
        pesquisa.pack(side="left", padx=8)
        ttk.Button(busca, text="Pesquisar", command=lambda n=nome: self.pesquisar(n)).pack(side="left")
        ttk.Button(busca, text="Mostrar todos", command=lambda n=nome: self.atualizar_tabela(n)).pack(side="left", padx=6)
        tree = ttk.Treeview(frame, columns=[c[0] for c in cfg["columns"]], show="headings", selectmode="browse")
        for col, titulo, largura in cfg["columns"]:
            tree.heading(col, text=titulo)
            tree.column(col, width=largura, minwidth=70, anchor="w")
        tree.pack(fill="both", expand=True)
        contador = ttk.Label(frame, text="Total: 0 registros encontrados", foreground="#52657d")
        contador.pack(anchor="e", pady=(6, 0))
        tree.bind("<<TreeviewSelect>>", lambda e, n=nome: self.selecionar(n))
        self.widgets[nome] = {"frame":frame,"entries":entradas,"tree":tree,"search":pesquisa,"selected_key":None,"contador":contador}

    def _montar_aba_notas(self):
        frame = ttk.Frame(self.abas, padding=14)
        self.abas.add(frame, text="Notas e avaliações")
        ttk.Label(frame, text="Módulo de avaliação acadêmica",
                  font=("Segoe UI", 14, "bold")).pack(anchor="w")
        ttk.Label(frame, text="Cadastre três notas e seus pesos. A média ponderada é calculada automaticamente.",
                  foreground="#52657d").pack(anchor="w", pady=(4, 10))

        form = ttk.LabelFrame(frame, text="Dados da avaliação", padding=10)
        form.pack(fill="x", pady=(0, 10))
        campos = [
            ("matricula", "Matrícula do aluno"), ("codigo_disciplina", "Código da disciplina"),
            ("nota1", "Nota 1 (0 a 10)"), ("peso1", "Peso 1"),
            ("nota2", "Nota 2 (0 a 10)"), ("peso2", "Peso 2"),
            ("nota3", "Nota 3 (0 a 10)"), ("peso3", "Peso 3")
        ]
        entradas = {}
        for i, (campo, rotulo) in enumerate(campos):
            linha, coluna = divmod(i, 4)
            celula = ttk.Frame(form)
            celula.grid(row=linha, column=coluna, sticky="ew", padx=5, pady=5)
            ttk.Label(celula, text=rotulo).pack(anchor="w")
            entrada = ttk.Entry(celula, width=18)
            entrada.pack(fill="x", pady=(3, 0))
            entradas[campo] = entrada
            form.columnconfigure(coluna, weight=1)

        acoes = ttk.Frame(frame)
        acoes.pack(fill="x", pady=(0, 8))
        ttk.Button(acoes, text="Cadastrar avaliação", command=self.cadastrar_nota).pack(side="left", padx=(0, 6))
        ttk.Button(acoes, text="Alterar selecionada", command=self.alterar_nota).pack(side="left", padx=6)
        ttk.Button(acoes, text="Excluir selecionada", command=self.excluir_nota).pack(side="left", padx=6)
        ttk.Button(acoes, text="Limpar campos", command=self.limpar_nota).pack(side="left", padx=6)
        ttk.Button(acoes, text="Gerar relatório de rendimento", command=self.relatorio_rendimento).pack(side="left", padx=6)

        colunas = ("matricula", "disciplina", "nota1", "peso1", "nota2", "peso2",
                   "nota3", "peso3", "media", "status")
        self.tabela_notas = ttk.Treeview(frame, columns=colunas, show="headings", selectmode="browse")
        titulos = {
            "matricula":"Matrícula", "disciplina":"Disciplina", "nota1":"Nota 1", "peso1":"Peso 1",
            "nota2":"Nota 2", "peso2":"Peso 2", "nota3":"Nota 3", "peso3":"Peso 3",
            "media":"Média", "status":"Status"
        }
        larguras = {"matricula":95, "disciplina":105, "nota1":65, "peso1":65, "nota2":65,
                    "peso2":65, "nota3":65, "peso3":65, "media":75, "status":100}
        for coluna in colunas:
            self.tabela_notas.heading(coluna, text=titulos[coluna])
            self.tabela_notas.column(coluna, width=larguras[coluna], minwidth=55, anchor="center")
        self.tabela_notas.pack(fill="both", expand=True)
        self.tabela_notas.bind("<<TreeviewSelect>>", self.selecionar_nota)
        self.contador_notas = ttk.Label(frame, text="Total: 0 avaliações")
        self.contador_notas.pack(anchor="e", pady=(6, 0))
        self.entradas_notas = entradas
        self.chave_nota_selecionada = None

    def valores_nota(self):
        campos = ["matricula", "codigo_disciplina", "nota1", "peso1",
                  "nota2", "peso2", "nota3", "peso3"]
        return [self.entradas_notas[c].get().strip() for c in campos]

    def criar_nota(self):
        return Nota(*self.valores_nota())

    def cadastrar_nota(self):
        try:
            gerenciadores["notas"].cadastrar(self.criar_nota())
            self.atualizar_tabela_notas()
            self.limpar_nota()
            messagebox.showinfo("Sucesso", "Avaliação cadastrada e salva em notas.txt.")
        except Exception as exc:
            messagebox.showerror("Não foi possível cadastrar", str(exc))

    def alterar_nota(self):
        if not self.chave_nota_selecionada:
            messagebox.showwarning("Selecione uma avaliação", "Selecione uma avaliação na tabela.")
            return
        try:
            gerenciadores["notas"].alterar(self.chave_nota_selecionada, self.criar_nota())
            self.atualizar_tabela_notas()
            self.limpar_nota()
            messagebox.showinfo("Sucesso", "Avaliação alterada. A média foi recalculada.")
        except Exception as exc:
            messagebox.showerror("Não foi possível alterar", str(exc))

    def excluir_nota(self):
        if not self.chave_nota_selecionada:
            messagebox.showwarning("Selecione uma avaliação", "Selecione uma avaliação na tabela.")
            return
        if not messagebox.askyesno("Confirmar exclusão", "Deseja excluir esta avaliação?"):
            return
        try:
            gerenciadores["notas"].excluir(self.chave_nota_selecionada)
            self.atualizar_tabela_notas()
            self.limpar_nota()
        except Exception as exc:
            messagebox.showerror("Não foi possível excluir", str(exc))

    def selecionar_nota(self, evento=None):
        selecionados = self.tabela_notas.selection()
        if not selecionados: return
        valores = self.tabela_notas.item(selecionados[0], "values")
        if not valores: return
        matricula, codigo = valores[0], valores[1]
        registro = gerenciadores["notas"].obter(f"{matricula}|{codigo}")
        if registro is None: return
        self.chave_nota_selecionada = registro.identificador
        campos = ["matricula", "codigo_disciplina", "nota1", "peso1",
                  "nota2", "peso2", "nota3", "peso3"]
        for campo in campos:
            entrada = self.entradas_notas[campo]
            entrada.delete(0, "end")
            entrada.insert(0, str(getattr(registro, campo)))

    def limpar_nota(self):
        for entrada in self.entradas_notas.values():
            entrada.delete(0, "end")
        self.chave_nota_selecionada = None
        for item in self.tabela_notas.selection():
            self.tabela_notas.selection_remove(item)

    def atualizar_tabela_notas(self):
        for item in self.tabela_notas.get_children():
            self.tabela_notas.delete(item)
        registros = gerenciadores["notas"].listar()
        for nota in registros:
            aluno = gerenciadores["alunos"].obter(nota.matricula)
            disciplina = gerenciadores["disciplinas"].obter(nota.codigo_disciplina)
            nome_disciplina = disciplina.nome if disciplina else nota.codigo_disciplina
            status = "Aprovado" if nota.media >= 7.0 else "Reprovado"
            self.tabela_notas.insert("", "end", values=(
                nota.matricula, nota.codigo_disciplina, f"{nota.nota1:g}", f"{nota.peso1:g}",
                f"{nota.nota2:g}", f"{nota.peso2:g}", f"{nota.nota3:g}", f"{nota.peso3:g}",
                f"{nota.media:.2f}", status
            ))
        self.contador_notas.configure(text=f"Total: {len(registros)} avaliações")

    def relatorio_rendimento(self):
        linhas = []
        for nota in gerenciadores["notas"].listar():
            aluno = gerenciadores["alunos"].obter(nota.matricula)
            disciplina = gerenciadores["disciplinas"].obter(nota.codigo_disciplina)
            nome_aluno = aluno.nome if aluno else "[aluno não encontrado]"
            nome_disciplina = disciplina.nome if disciplina else "[disciplina não encontrada]"
            status = "Aprovado" if nota.media >= 7.0 else "Reprovado"
            linhas.append(
                f"Aluno: {nome_aluno} | Disciplina: {nome_disciplina}\\n"
                f"Notas/Pesos: {nota.nota1:g} (peso {nota.peso1:g}); "
                f"{nota.nota2:g} (peso {nota.peso2:g}); {nota.nota3:g} (peso {nota.peso3:g})\\n"
                f"Média final: {nota.media:.2f} | Status: {status}"
            )
        if not linhas:
            linhas = ["Nenhuma avaliação cadastrada."]
        janela = tk.Toplevel(self.root)
        janela.title("Relatório de rendimento escolar")
        janela.geometry("850x550")
        texto = tk.Text(janela, wrap="word", font=("Consolas", 10), padx=12, pady=12)
        texto.pack(fill="both", expand=True)
        texto.insert("1.0", "RELATÓRIO DE RENDIMENTO ESCOLAR\\n" + "="*34 + "\\n\\n" + "\\n\\n".join(linhas))
        texto.configure(state="disabled")

    def _montar_relatorio(self):
        frame = ttk.Frame(self.abas, padding=16)
        self.abas.add(frame, text="Relatório integrado")
        ttk.Label(frame, text="Relatório acadêmico completo", font=("Segoe UI",14,"bold")).pack(anchor="w")
        ttk.Label(frame, text="Relaciona cada aluno ao curso, à disciplina e ao professor.").pack(anchor="w", pady=(5,12))
        filtros = ttk.Frame(frame)
        filtros.pack(fill="x", pady=(0, 10))
        ttk.Label(filtros, text="Curso:").pack(side="left")
        self.filtro_curso = ttk.Combobox(filtros, state="readonly", width=24)
        self.filtro_curso.pack(side="left", padx=(6, 12))
        ttk.Button(filtros, text="Alunos por curso", command=self.relatorio_por_curso).pack(side="left", padx=(0, 12))
        ttk.Label(filtros, text="Disciplina:").pack(side="left")
        self.filtro_disciplina = ttk.Combobox(filtros, state="readonly", width=28)
        self.filtro_disciplina.pack(side="left", padx=6)
        ttk.Button(filtros, text="Alunos por disciplina", command=self.relatorio_por_disciplina).pack(side="left", padx=6)
        ttk.Button(frame, text="Gerar relatório integrado", command=self.gerar_relatorio).pack(anchor="w", pady=(0,10))
        self.relatorio = tk.Text(frame, wrap="word", font=("Consolas", 10), bg="white",
                                 fg="#1e293b", padx=12, pady=12, relief="solid", borderwidth=1)
        self.relatorio.pack(fill="both", expand=True)
        self.relatorio.insert("1.0", "Clique em 'Gerar relatório' para exibir os vínculos cadastrados.")
        self.relatorio.configure(state="disabled")

    def ger(self, nome):
        return gerenciadores[self.configs[nome]["key"]]

    def valores_formulario(self, nome):
        cfg, w = self.configs[nome], self.widgets[nome]
        return [w["entries"][campo].get().strip() for campo, _ in cfg["fields"]]

    def criar_objeto(self, nome, valores):
        return self.configs[nome]["class"](*valores)

    def cadastrar(self, nome):
        try:
            obj = self.criar_objeto(nome, self.valores_formulario(nome))
            self.ger(nome).cadastrar(obj)
            self.atualizar_tudo()
            self.limpar(nome)
            messagebox.showinfo("Sucesso", "Registro cadastrado e salvo no arquivo TXT.")
        except Exception as exc:
            messagebox.showerror("Não foi possível cadastrar", str(exc))

    def alterar(self, nome):
        w, cfg = self.widgets[nome], self.configs[nome]
        chave = w["selected_key"]
        if not chave:
            messagebox.showwarning("Selecione um registro", "Selecione uma linha na tabela antes de alterar.")
            return
        try:
            obj = self.criar_objeto(nome, self.valores_formulario(nome))
            self.ger(nome).alterar(chave, obj)
            self.atualizar_tudo()
            self.limpar(nome)
            messagebox.showinfo("Sucesso", "Registro alterado e salvo no arquivo TXT.")
        except Exception as exc:
            messagebox.showerror("Não foi possível alterar", str(exc))

    def excluir(self, nome):
        w, cfg = self.widgets[nome], self.configs[nome]
        chave = w["selected_key"]
        if not chave:
            messagebox.showwarning("Selecione um registro", "Selecione uma linha na tabela antes de excluir.")
            return
        if not messagebox.askyesno("Confirmar exclusão", f"Deseja excluir o registro '{chave}'?"):
            return
        try:
            self.ger(nome).excluir(chave)
            self.atualizar_tudo()
            self.limpar(nome)
            messagebox.showinfo("Sucesso", "Registro excluído.")
        except Exception as exc:
            messagebox.showerror("Não foi possível excluir", str(exc))

    def selecionar(self, nome):
        w, cfg = self.widgets[nome], self.configs[nome]
        selecionados = w["tree"].selection()
        if not selecionados: return
        valores = w["tree"].item(selecionados[0], "values")
        if not valores: return
        chave_campo = cfg["id"]
        registro = self.ger(nome).obter(valores[[c[0] for c in cfg["columns"]].index(chave_campo)])
        if registro is None: return
        w["selected_key"] = getattr(registro, chave_campo)
        for campo, _ in cfg["fields"]:
            entrada = w["entries"][campo]
            entrada.delete(0, "end")
            entrada.insert(0, str(getattr(registro, campo)))

    def limpar(self, nome):
        w = self.widgets[nome]
        for entrada in w["entries"].values(): entrada.delete(0, "end")
        w["selected_key"] = None
        for item in w["tree"].selection(): w["tree"].selection_remove(item)

    def atualizar_tabela(self, nome, registros=None):
        w, cfg = self.widgets[nome], self.configs[nome]
        tree = w["tree"]
        for item in tree.get_children(): tree.delete(item)
        if registros is None: registros = self.ger(nome).listar()
        for obj in registros:
            tree.insert("", "end", values=[getattr(obj, c[0]) for c in cfg["columns"]])
        plural = {"Alunos":"alunos", "Cursos":"cursos", "Professores":"professores", "Disciplinas":"disciplinas"}[nome]
        w["contador"].configure(text=f"Total: {len(registros)} {plural} encontrados")

    def pesquisar(self, nome):
        termo = self.widgets[nome]["search"].get()
        self.atualizar_tabela(nome, self.ger(nome).buscar(termo))

    def atualizar_tudo(self):
        for nome in self.configs: self.atualizar_tabela(nome)
        cursos = gerenciadores["cursos"].listar()
        disciplinas = gerenciadores["disciplinas"].listar()
        self.filtro_curso["values"] = [f"{c.codigo_curso} - {c.nome}" for c in cursos]
        self.filtro_disciplina["values"] = [f"{d.codigo_disciplina} - {d.nome}" for d in disciplinas]
        if hasattr(self, "tabela_notas"):
            self.atualizar_tabela_notas()

    def exibir_relatorio(self, titulo, linhas):
        if not linhas:
            linhas = ["Nenhum registro encontrado para o filtro selecionado."]
        texto = titulo + "\n" + "=" * len(titulo) + "\n\n" + "\n\n".join(linhas) + f"\n\nTotal: {len([x for x in linhas if not x.startswith('Nenhum registro')])} registros encontrados."
        self.relatorio.configure(state="normal")
        self.relatorio.delete("1.0", "end")
        self.relatorio.insert("1.0", texto)
        self.relatorio.configure(state="disabled")

    def relatorio_por_curso(self):
        escolha = self.filtro_curso.get()
        if not escolha:
            messagebox.showwarning("Selecione um curso", "Escolha um curso para gerar o relatório.")
            return
        codigo = escolha.split(" - ", 1)[0]
        alunos = [a for a in gerenciadores["alunos"].listar() if a.codigo_curso == codigo]
        curso = gerenciadores["cursos"].obter(codigo)
        self.exibir_relatorio(f"Alunos do curso {curso.nome if curso else codigo}", [f"Matrícula: {a.matricula} | Nome: {a.nome} | CPF: {a.cpf} | E-mail: {a.email}" for a in alunos])

    def relatorio_por_disciplina(self):
        escolha = self.filtro_disciplina.get()
        if not escolha:
            messagebox.showwarning("Selecione uma disciplina", "Escolha uma disciplina para gerar o relatório.")
            return
        codigo = escolha.split(" - ", 1)[0]
        disciplina = gerenciadores["disciplinas"].obter(codigo)
        curso = gerenciadores["cursos"].obter(disciplina.codigo_curso) if disciplina else None
        alunos = [a for a in gerenciadores["alunos"].listar() if disciplina and a.codigo_curso == disciplina.codigo_curso]
        linhas = [f"Matrícula: {a.matricula} | Nome: {a.nome} | Curso: {a.codigo_curso}" for a in alunos]
        self.exibir_relatorio(f"Alunos da disciplina {disciplina.nome if disciplina else codigo} (Curso: {curso.nome if curso else 'não encontrado'})", linhas)

    def gerar_relatorio(self):
        alunos = gerenciadores["alunos"].listar()
        cursos = gerenciadores["cursos"]
        disciplinas = gerenciadores["disciplinas"].listar()
        professores = gerenciadores["professores"]
        linhas = []
        for aluno in alunos:
            curso = cursos.obter(aluno.codigo_curso)
            relacionadas = [d for d in disciplinas if d.codigo_curso == aluno.codigo_curso]
            if not relacionadas:
                linhas.append(f"O Aluno {aluno.nome} está matriculado no curso {curso.nome if curso else '[curso não encontrado]'}, mas ainda não há disciplina cadastrada para esse curso.")
                continue
            for disciplina in relacionadas:
                professor = professores.obter(disciplina.codigo_professor)
                linhas.append(
                    f"O Aluno {aluno.nome} está matriculado no curso {curso.nome if curso else '[curso não encontrado]'}, "
                    f"assistindo a disciplina {disciplina.nome} com o professor {professor.nome if professor else '[professor não encontrado]'}."
                )
        if not linhas:
            linhas = ["Não há alunos cadastrados para gerar o relatório. Cadastre curso, professor, disciplina e aluno para demonstrar a integração."]
        self.relatorio.configure(state="normal")
        self.relatorio.delete("1.0", "end")
        self.relatorio.insert("1.0", "\n\n".join(linhas))
        self.relatorio.configure(state="disabled")


def main():
    root = tk.Tk()
    Aplicacao(root)
    root.mainloop()

if __name__ == "__main__":
    main()
