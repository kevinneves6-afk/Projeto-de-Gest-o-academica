# Sistema de Gestão Acadêmica Integrado

Aplicação desktop em Python com Tkinter, usando Programação Orientada a Objetos e persistência em arquivos TXT separados por ponto e vírgula.

## Requisitos
- Python 3.10 ou superior (Tkinter normalmente já vem com Python no Windows).
- Não exige bibliotecas externas.

## Como executar
1. Extraia a pasta do ZIP.
2. Abra a pasta no VS Code.
3. Execute `python main.py` no terminal.
   - No Windows, também pode usar `py main.py`.

## Módulos
- Aluno: matrícula, nome, CPF, e-mail e código do curso.
- Curso: código, nome e modalidade (Presencial/EAD).
- Professor: código, nome, CPF e especialidade.
- Disciplina: código, nome, carga horária, código do professor e código do curso.

## Funcionalidades
- Cadastro, listagem, alteração, exclusão e pesquisa.
- Validação básica de campos e de relacionamentos.
- Dados carregados dos arquivos TXT ao iniciar e persistidos após cada alteração.
- Relatório integrado: aluno, curso, disciplina e professor.
- Interface gráfica com abas, formulários e botões.

## Arquivos de dados
Os arquivos `alunos.txt`, `cursos.txt`, `professores.txt` e `disciplinas.txt` ficam na pasta `dados/`. Cada registro ocupa uma linha e os campos são separados por `;`.
Os arquivos são criados automaticamente na primeira execução.

## Formato dos arquivos
- `alunos.txt`: matrícula;nome;cpf;email;codigo_curso
- `cursos.txt`: codigo_curso;nome;modalidade
- `professores.txt`: codigo_professor;nome;cpf;especialidade
- `disciplinas.txt`: codigo_disciplina;nome;carga_horaria;codigo_professor;codigo_curso

O sistema rejeita `;` nos campos de texto para preservar o formato do arquivo.

## Complemento de requisitos (RF19–RF33)

A versão atualizada contempla:
- Identificadores únicos para matrícula/códigos e campos obrigatórios.
- CPF com 11 dígitos (aceita entrada com pontuação e armazena somente os dígitos), e-mail com validação simples e carga horária inteira positiva.
- Bloqueio de ponto e vírgula e quebras de linha nos campos de texto para preservar os arquivos TXT.
- Verificação de curso ao cadastrar aluno e de professor/curso ao cadastrar disciplina.
- Proteção contra exclusão de cursos com alunos ou disciplinas vinculados e de professores vinculados a disciplinas.
- Relatórios de alunos por curso, alunos por disciplina e relatório integrado.
- Contador de registros em cada tabela, confirmação antes da exclusão e avisos amigáveis para arquivos ausentes, inacessíveis ou com linhas inválidas.
- Interface gráfica organizada em abas e listagens em tabelas.

## Como executar

1. Instale o Python 3.10 ou superior.
2. Extraia o ZIP mantendo a pasta `sistema_gestao_academica`.
3. Abra um terminal nessa pasta e execute `python main.py`.
4. Cadastre primeiro os cursos e professores; depois, disciplinas e alunos, respeitando os vínculos.

Os dados ficam na pasta `dados/`, em arquivos TXT separados por ponto e vírgula. Faça uma cópia de segurança desses arquivos antes de alterações manuais.


## Módulo de Avaliação Acadêmica (RF19–RF24)

- **RF19:** nova entidade `Nota`, vinculada à matrícula do aluno e ao código da disciplina, com três notas e três pesos.
- **RF20:** persistência no arquivo `dados/notas.txt`, no formato `matricula;codigo_disciplina;nota1;peso1;nota2;peso2;nota3;peso3`.
- **RF21:** cálculo automático da média ponderada durante a listagem e a geração do relatório.
- **RF22:** notas limitadas ao intervalo de 0,0 a 10,0; pesos devem ser positivos para permitir o cálculo; a média é protegida pelo teto de 10,0.
- **RF23:** relatório de rendimento com nome do aluno, nome da disciplina, notas, pesos, média final e status (Aprovado para média maior ou igual a 7,0; Reprovado abaixo de 7,0).
- **RF24:** a média não é gravada no arquivo; é recalculada a cada leitura a partir das notas e pesos atuais. Alterações são refletidas automaticamente na próxima listagem/relatório.

A interface inclui a aba **Notas e avaliações**, com cadastro, alteração, exclusão, listagem e relatório de rendimento. O sistema verifica se aluno e disciplina existem e se a disciplina pertence ao curso do aluno. Também impede excluir aluno ou disciplina que possua avaliação vinculada.
