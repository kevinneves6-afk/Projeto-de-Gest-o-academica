"""Entidades do sistema acadêmico: atributos protegidos e propriedades."""


class Entidade:
    def __init__(self):
        pass

    @staticmethod
    def validar_texto(valor, campo):
        valor = str(valor).strip()
        if not valor:
            raise ValueError(f"O campo '{campo}' é obrigatório.")
        if ";" in valor or "\n" in valor or "\r" in valor:
            raise ValueError(f"O campo '{campo}' não pode conter ';' ou quebra de linha.")
        return valor


class Aluno(Entidade):
    def __init__(self, matricula, nome, cpf, email, codigo_curso):
        super().__init__()
        self.matricula = matricula
        self.nome = nome
        self.cpf = cpf
        self.email = email
        self.codigo_curso = codigo_curso

    @property
    def matricula(self): return self._matricula
    @matricula.setter
    def matricula(self, v): self._matricula = self.validar_texto(v, "Matrícula")
    @property
    def nome(self): return self._nome
    @nome.setter
    def nome(self, v): self._nome = self.validar_texto(v, "Nome")
    @property
    def cpf(self): return self._cpf
    @cpf.setter
    def cpf(self, v):
        v = self.validar_texto(v, "CPF")
        digitos = "".join(ch for ch in v if ch.isdigit())
        if len(digitos) != 11 or any(not (ch.isdigit() or ch in ".-/ ") for ch in v):
            raise ValueError("CPF deve conter 11 dígitos (com ou sem pontuação).")
        self._cpf = digitos
    @property
    def email(self): return self._email
    @email.setter
    def email(self, v):
        v = self.validar_texto(v, "E-mail")
        if "@" not in v or "." not in v.split("@")[-1]:
            raise ValueError("Informe um e-mail válido.")
        self._email = v
    @property
    def codigo_curso(self): return self._codigo_curso
    @codigo_curso.setter
    def codigo_curso(self, v): self._codigo_curso = self.validar_texto(v, "Código do curso")

    def __str__(self):
        return f"Matrícula: {self.matricula} | Nome: {self.nome} | CPF: {self.cpf} | E-mail: {self.email} | Curso: {self.codigo_curso}"
    def para_linha(self):
        return ";".join([self.matricula, self.nome, self.cpf, self.email, self.codigo_curso])
    @classmethod
    def de_linha(cls, linha):
        partes = linha.rstrip("\n").split(";")
        if len(partes) != 5: raise ValueError("Registro de aluno inválido")
        return cls(*partes)


class Curso(Entidade):
    def __init__(self, codigo_curso, nome, modalidade):
        self.codigo_curso = codigo_curso
        self.nome = nome
        self.modalidade = modalidade
    @property
    def codigo_curso(self): return self._codigo_curso
    @codigo_curso.setter
    def codigo_curso(self, v): self._codigo_curso = self.validar_texto(v, "Código do curso")
    @property
    def nome(self): return self._nome
    @nome.setter
    def nome(self, v): self._nome = self.validar_texto(v, "Nome")
    @property
    def modalidade(self): return self._modalidade
    @modalidade.setter
    def modalidade(self, v):
        v = self.validar_texto(v, "Modalidade").capitalize()
        if v not in ("Presencial", "Ead"): raise ValueError("Modalidade deve ser Presencial ou EAD.")
        self._modalidade = "EAD" if v == "Ead" else v
    def __str__(self): return f"Código: {self.codigo_curso} | {self.nome} | {self.modalidade}"
    def para_linha(self): return ";".join([self.codigo_curso, self.nome, self.modalidade])
    @classmethod
    def de_linha(cls, linha):
        p = linha.rstrip("\n").split(";")
        if len(p) != 3: raise ValueError("Registro de curso inválido")
        return cls(*p)


class Professor(Entidade):
    def __init__(self, codigo_professor, nome, cpf, especialidade):
        self.codigo_professor = codigo_professor
        self.nome = nome
        self.cpf = cpf
        self.especialidade = especialidade
    @property
    def codigo_professor(self): return self._codigo_professor
    @codigo_professor.setter
    def codigo_professor(self, v): self._codigo_professor = self.validar_texto(v, "Código do professor")
    @property
    def nome(self): return self._nome
    @nome.setter
    def nome(self, v): self._nome = self.validar_texto(v, "Nome")
    @property
    def cpf(self): return self._cpf
    @cpf.setter
    def cpf(self, v):
        v = self.validar_texto(v, "CPF")
        digitos = "".join(ch for ch in v if ch.isdigit())
        if len(digitos) != 11 or any(not (ch.isdigit() or ch in ".-/ ") for ch in v):
            raise ValueError("CPF deve conter 11 dígitos (com ou sem pontuação).")
        self._cpf = digitos
    @property
    def especialidade(self): return self._especialidade
    @especialidade.setter
    def especialidade(self, v): self._especialidade = self.validar_texto(v, "Especialidade")
    def __str__(self): return f"Código: {self.codigo_professor} | Nome: {self.nome} | CPF: {self.cpf} | Especialidade: {self.especialidade}"
    def para_linha(self): return ";".join([self.codigo_professor, self.nome, self.cpf, self.especialidade])
    @classmethod
    def de_linha(cls, linha):
        p = linha.rstrip("\n").split(";")
        if len(p) != 4: raise ValueError("Registro de professor inválido")
        return cls(*p)


class Disciplina(Entidade):
    def __init__(self, codigo_disciplina, nome, carga_horaria, codigo_professor, codigo_curso):
        self.codigo_disciplina = codigo_disciplina
        self.nome = nome
        self.carga_horaria = carga_horaria
        self.codigo_professor = codigo_professor
        self.codigo_curso = codigo_curso
    @property
    def codigo_disciplina(self): return self._codigo_disciplina
    @codigo_disciplina.setter
    def codigo_disciplina(self, v): self._codigo_disciplina = self.validar_texto(v, "Código da disciplina")
    @property
    def nome(self): return self._nome
    @nome.setter
    def nome(self, v): self._nome = self.validar_texto(v, "Nome")
    @property
    def carga_horaria(self): return self._carga_horaria
    @carga_horaria.setter
    def carga_horaria(self, v):
        v = self.validar_texto(v, "Carga horária")
        try: n = int(v)
        except ValueError: raise ValueError("Carga horária deve ser um número inteiro.")
        if n <= 0: raise ValueError("Carga horária deve ser maior que zero.")
        self._carga_horaria = str(n)
    @property
    def codigo_professor(self): return self._codigo_professor
    @codigo_professor.setter
    def codigo_professor(self, v): self._codigo_professor = self.validar_texto(v, "Código do professor")
    @property
    def codigo_curso(self): return self._codigo_curso
    @codigo_curso.setter
    def codigo_curso(self, v): self._codigo_curso = self.validar_texto(v, "Código do curso")
    def __str__(self): return f"Código: {self.codigo_disciplina} | {self.nome} | {self.carga_horaria}h | Professor: {self.codigo_professor} | Curso: {self.codigo_curso}"
    def para_linha(self): return ";".join([self.codigo_disciplina, self.nome, self.carga_horaria, self.codigo_professor, self.codigo_curso])
    @classmethod
    def de_linha(cls, linha):
        p = linha.rstrip("\n").split(";")
        if len(p) != 5: raise ValueError("Registro de disciplina inválido")
        return cls(*p)



class Nota(Entidade):
    """Avaliação de um aluno em uma disciplina, com três notas e respectivos pesos."""
    def __init__(self, matricula, codigo_disciplina, nota1, peso1, nota2, peso2, nota3, peso3):
        self.matricula = self.validar_texto(matricula, "Matrícula")
        self.codigo_disciplina = self.validar_texto(codigo_disciplina, "Código da disciplina")
        self.nota1 = nota1
        self.peso1 = peso1
        self.nota2 = nota2
        self.peso2 = peso2
        self.nota3 = nota3
        self.peso3 = peso3

    @staticmethod
    def _validar_nota(valor, campo):
        try: numero = float(str(valor).replace(",", "."))
        except (TypeError, ValueError): raise ValueError(f"{campo} deve ser numérica.")
        if not 0.0 <= numero <= 10.0:
            raise ValueError(f"{campo} deve estar entre 0,0 e 10,0.")
        return numero

    @staticmethod
    def _validar_peso(valor, campo):
        try: numero = float(str(valor).replace(",", "."))
        except (TypeError, ValueError): raise ValueError(f"{campo} deve ser numérico.")
        if numero <= 0:
            raise ValueError(f"{campo} deve ser maior que zero.")
        return numero

    @property
    def nota1(self): return self._nota1
    @nota1.setter
    def nota1(self, v): self._nota1 = self._validar_nota(v, "Nota 1")
    @property
    def nota2(self): return self._nota2
    @nota2.setter
    def nota2(self, v): self._nota2 = self._validar_nota(v, "Nota 2")
    @property
    def nota3(self): return self._nota3
    @nota3.setter
    def nota3(self, v): self._nota3 = self._validar_nota(v, "Nota 3")
    @property
    def peso1(self): return self._peso1
    @peso1.setter
    def peso1(self, v): self._peso1 = self._validar_peso(v, "Peso 1")
    @property
    def peso2(self): return self._peso2
    @peso2.setter
    def peso2(self, v): self._peso2 = self._validar_peso(v, "Peso 2")
    @property
    def peso3(self): return self._peso3
    @peso3.setter
    def peso3(self, v): self._peso3 = self._validar_peso(v, "Peso 3")

    @property
    def identificador(self): return f"{self.matricula}|{self.codigo_disciplina}"

    @property
    def media(self):
        total_pesos = self.peso1 + self.peso2 + self.peso3
        resultado = ((self.nota1*self.peso1) + (self.nota2*self.peso2) + (self.nota3*self.peso3)) / total_pesos
        return min(resultado, 10.0)

    def para_linha(self):
        valores = [self.matricula, self.codigo_disciplina,
                   f"{self.nota1:g}", f"{self.peso1:g}",
                   f"{self.nota2:g}", f"{self.peso2:g}",
                   f"{self.nota3:g}", f"{self.peso3:g}"]
        return ";".join(valores)

    @classmethod
    def de_linha(cls, linha):
        partes = linha.rstrip("\n").split(";")
        if len(partes) != 8: raise ValueError("Registro de nota inválido")
        return cls(*partes)
