"""Gerenciadores CRUD e persistência em TXT delimitado por ponto e vírgula."""
from pathlib import Path
from models import Aluno, Curso, Professor, Disciplina, Nota

DATA_DIR = Path(__file__).resolve().parent / "dados"


class GerenciadorBase:
    entidade = None
    arquivo = None
    chave = None

    def __init__(self):
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        self.caminho = DATA_DIR / self.arquivo
        self.registros = []
        self.avisos_carregamento = []
        self.carregar()

    def carregar(self):
        self.registros = []
        self.avisos_carregamento = []
        if not self.caminho.exists():
            try:
                self.caminho.touch(encoding="utf-8")
                self.avisos_carregamento.append(f"O arquivo {self.arquivo} não existia e foi recriado vazio.")
            except OSError as exc:
                self.avisos_carregamento.append(f"Arquivo {self.arquivo} inacessível: {exc}")
            return
        try:
            with self.caminho.open("r", encoding="utf-8") as arq:
                for numero, linha in enumerate(arq, 1):
                    if not linha.strip(): continue
                    try: self.registros.append(self.entidade.de_linha(linha))
                    except Exception as exc:
                        self.avisos_carregamento.append(f"{self.arquivo}, linha {numero}: registro ignorado ({exc}).")
        except (OSError, UnicodeError) as exc:
            self.avisos_carregamento.append(f"Não foi possível ler {self.arquivo}: {exc}")

    def salvar(self):
        temporario = self.caminho.with_suffix(".tmp")
        try:
            with temporario.open("w", encoding="utf-8", newline="") as arq:
                for registro in self.registros:
                    arq.write(registro.para_linha() + "\n")
            temporario.replace(self.caminho)
        except OSError as exc:
            raise ValueError(f"Não foi possível salvar {self.arquivo}. Verifique as permissões e o espaço em disco. Detalhes: {exc}") from exc

    def listar(self):
        return list(self.registros)

    def buscar(self, termo):
        termo = str(termo).strip().casefold()
        if not termo: return self.listar()
        return [r for r in self.registros if termo in str(getattr(r, self.chave)).casefold()
                or termo in getattr(r, "nome", "").casefold()]

    def obter(self, chave):
        chave = str(chave).strip()
        return next((r for r in self.registros if getattr(r, self.chave) == chave), None)

    def cadastrar(self, registro):
        chave = getattr(registro, self.chave)
        if self.obter(chave): raise ValueError(f"Já existe registro com identificador '{chave}'.")
        self.validar_relacionamentos(registro)
        self.registros.append(registro)
        self.salvar()

    def validar_relacionamentos(self, registro):
        pass

    def alterar(self, chave_original, atualizado):
        antigo = self.obter(chave_original)
        if antigo is None: raise ValueError("Registro não encontrado.")
        chave_nova = getattr(atualizado, self.chave)
        if chave_nova != chave_original and self.obter(chave_nova):
            raise ValueError(f"Já existe registro com identificador '{chave_nova}'.")
        self.validar_relacionamentos(atualizado)
        indice = self.registros.index(antigo)
        self.registros[indice] = atualizado
        self.salvar()

    def excluir(self, chave):
        registro = self.obter(chave)
        if registro is None: raise ValueError("Registro não encontrado.")
        self.validar_exclusao(registro)
        self.registros.remove(registro)
        self.salvar()

    def validar_exclusao(self, registro):
        pass


class GerenciadorCursos(GerenciadorBase):
    entidade, arquivo, chave = Curso, "cursos.txt", "codigo_curso"
    def validar_exclusao(self, registro):
        if any(a.codigo_curso == registro.codigo_curso for a in gerenciadores["alunos"].listar()):
            raise ValueError("Não é possível excluir: há alunos vinculados a este curso.")
        if any(d.codigo_curso == registro.codigo_curso for d in gerenciadores["disciplinas"].listar()):
            raise ValueError("Não é possível excluir: há disciplinas vinculadas a este curso.")


class GerenciadorProfessores(GerenciadorBase):
    entidade, arquivo, chave = Professor, "professores.txt", "codigo_professor"
    def validar_exclusao(self, registro):
        if any(d.codigo_professor == registro.codigo_professor for d in gerenciadores["disciplinas"].listar()):
            raise ValueError("Não é possível excluir: há disciplinas vinculadas a este professor.")


class GerenciadorAlunos(GerenciadorBase):
    entidade, arquivo, chave = Aluno, "alunos.txt", "matricula"
    def validar_exclusao(self, registro):
        if "notas" in gerenciadores and any(n.matricula == registro.matricula for n in gerenciadores["notas"].listar()):
            raise ValueError("Não é possível excluir: há avaliações vinculadas a este aluno.")
    def validar_relacionamentos(self, registro):
        if not gerenciadores["cursos"].obter(registro.codigo_curso):
            raise ValueError("O código do curso informado não existe. Cadastre o curso primeiro.")


class GerenciadorDisciplinas(GerenciadorBase):
    entidade, arquivo, chave = Disciplina, "disciplinas.txt", "codigo_disciplina"
    def validar_exclusao(self, registro):
        if "notas" in gerenciadores and any(n.codigo_disciplina == registro.codigo_disciplina for n in gerenciadores["notas"].listar()):
            raise ValueError("Não é possível excluir: há avaliações vinculadas a esta disciplina.")
    def validar_relacionamentos(self, registro):
        if not gerenciadores["professores"].obter(registro.codigo_professor):
            raise ValueError("O código do professor informado não existe. Cadastre o professor primeiro.")
        if not gerenciadores["cursos"].obter(registro.codigo_curso):
            raise ValueError("O código do curso informado não existe. Cadastre o curso primeiro.")


# A inicialização ocorre em ordem para que os gerenciadores possam validar vínculos.
gerenciadores = {}
gerenciadores["cursos"] = GerenciadorCursos()
gerenciadores["professores"] = GerenciadorProfessores()
gerenciadores["alunos"] = GerenciadorAlunos()
gerenciadores["disciplinas"] = GerenciadorDisciplinas()


class GerenciadorNotas(GerenciadorBase):
    entidade, arquivo, chave = Nota, "notas.txt", "identificador"

    def validar_relacionamentos(self, registro):
        if not gerenciadores["alunos"].obter(registro.matricula):
            raise ValueError("A matrícula informada não existe. Cadastre o aluno primeiro.")
        if not gerenciadores["disciplinas"].obter(registro.codigo_disciplina):
            raise ValueError("O código da disciplina informado não existe. Cadastre a disciplina primeiro.")
        aluno = gerenciadores["alunos"].obter(registro.matricula)
        disciplina = gerenciadores["disciplinas"].obter(registro.codigo_disciplina)
        if aluno.codigo_curso != disciplina.codigo_curso:
            raise ValueError("A disciplina não pertence ao curso do aluno.")

    def buscar(self, termo):
        termo = str(termo).strip().casefold()
        if not termo: return self.listar()
        return [r for r in self.registros if termo in r.matricula.casefold()
                or termo in r.codigo_disciplina.casefold()]

gerenciadores["notas"] = GerenciadorNotas()